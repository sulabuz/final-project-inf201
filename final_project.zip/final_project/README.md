# git-java-fx-test

Рома және Султанайдің алғалшқы Java FX программасы
